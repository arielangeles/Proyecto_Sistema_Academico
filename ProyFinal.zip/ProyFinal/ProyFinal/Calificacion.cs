﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyFinal
{
    public class Calificacion: Estudiante
    {
        private int calificaciones;

        public int Calificaciones
        {
            get
            {
                return this.calificaciones;
            }
            set
            {
                if (value > 100)
                {
                    value = 100;
                }
                this.calificaciones = value;
            }
        }



    }
}
