﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyFinal
{
    public class Estudiante : Usuario
    {
        
        private string carrera;
        

        public string Carrera
        {
            get
            {
                return this.carrera;
            }
            set
            {
                this.carrera = value;
            }
        }

       

    }
}
