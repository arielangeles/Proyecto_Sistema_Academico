﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyFinal
{
    public class Evaluacion
    {
        public string estudianteId;
        public static List<string> preguntas = new List<string>();
        public List<int> puntuaciones = new List<int>();

        /* Pasar como parametro el Id del estudiante en la funcion Evaluar()
         * para asi tener el control de que un estudiante no evalue dos veces.
        */

        public void Evaluar(string _estudianteId)
        {
            this.estudianteId = _estudianteId;
            var score = 0;
            foreach (string pregunta in preguntas)
            {
                Console.WriteLine(pregunta);
                score = int.Parse(Console.ReadLine());
                puntuaciones.Add(score);
            }
        }

        public int Promediar()
        {
            var promedio = 0;
            foreach (int puntuacion in puntuaciones)
            {
                promedio += puntuacion;
            }
            return promedio;
        }

        public static void RegistrarPregunta()
        {
            preguntas.Add("Muestra dominio en la asignatura?");
            preguntas.Add("Se nota entusiasmo por la asignatura?");
            preguntas.Add("Es responsable en todo momento?");
            preguntas.Add("Se comunica de forma clara y facil de comprender?");
            preguntas.Add("Trata a sus alumnos con respeto en todo momento?");
            preguntas.Add("Promueve la participacion de los alumnos?");
            preguntas.Add("Demuestra que cada clase tuvo una preparacion previa?");
            preguntas.Add("Crea un buen ambiente en su clase?");
            preguntas.Add("Hace la clases entretenidas a la vez que educacionales?");

        }

        public static void EvaluacionProfesoral()
        {
            Profesor profesor = new Profesor();
            RegistrarPregunta();
            Console.WriteLine("Bienvenido al sistema de evaluacion profesoral");

            Console.WriteLine("Ingrese su ID: ");
            string id = Console.ReadLine();

            foreach(Profesor prof in RegistroProfesores.listaProfesor)
            {
                Console.WriteLine("{0,-10}", prof.Nombre , prof.Materia );
            }

            profesor.RealizarEvaluacion(id);


            profesor.PromedioEvaluacion();
            Console.ReadKey();
            
        }

    }
}
