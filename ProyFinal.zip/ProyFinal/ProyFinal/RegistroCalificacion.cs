﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyFinal
{
    public static class RegistroCalificacion
    {
        public static List<Calificacion> listaCalificacion;

        static RegistroCalificacion()
        {
            listaCalificacion = new List<Calificacion>();
        }

        public static void AgregarCalificacion(Calificacion calificacion)
        {
            listaCalificacion.Add(calificacion);
        }

        public static bool FinishCalificacion;

        public static void CalificarMateria()
        {
            do
            {
                FinishCalificacion = false;
                Console.WriteLine("----------------------------------------------------");
                Console.WriteLine(@"\\\\\ Bienvenido al sistema de calificaciones \\\\\");
                Console.WriteLine("----------------------------------------------------");
                Console.WriteLine("");
                Console.Write("Escriba el nombre de la materia que desea calificar: ");
                string materia = Console.ReadLine();
                Console.Write("Indique la seccion: ");
                byte seccion = byte.Parse(Console.ReadLine());
                #region
                foreach (Seleccion seleccion in RegistroSeleccion.listaSeleccion)
                {
                    if (materia == seleccion.Materia && seccion == seleccion.Seccion)
                    {
                        foreach (Estudiante estudiante in RegistroEstudiante.listaEstudiante)
                        {
                            Calificacion calificacion = new Calificacion();
                            Console.Write($"Ingrese la calificacion de {estudiante.Nombre} - {estudiante.ID}: ");
                             calificacion.Calificaciones = int.Parse(Console.ReadLine());
                            if (calificacion.Calificaciones > 89 && calificacion.Calificaciones < 101)
                            {
                                calificacion.Calificaciones.ToString("A");
                               
                            }
                            else if (calificacion.Calificaciones > 84)
                            {
                                calificacion.Calificaciones.ToString("B+");
                                
                            }
                            else if (calificacion.Calificaciones > 79 /*&& estudiante.Calificacion < 85*/)
                            {
                                calificacion.Calificaciones.ToString("B");
                               
                            }
                            else if (calificacion.Calificaciones > 74 /*&&*/ /*estudiante.Calificacion < 80*/)
                            {
                                calificacion.Calificaciones.ToString("C+");
                              
                            }
                            else if (calificacion.Calificaciones > 69/* &&*/ /*estudiante.Calificacion < 75*/)
                            {
                                calificacion.Calificaciones.ToString("C");
                               
                            }
                            else if (calificacion.Calificaciones > 59/* &&*/ /*estudiante.Calificacion < 70*/)
                            {
                                calificacion.Calificaciones.ToString("D");
                                
                            }
                            else if (calificacion.Calificaciones <= 59)
                            {
                                calificacion.Calificaciones.ToString("F");
                               
                            }
                            else
                            {
                                Console.WriteLine(" Numero invalido. ");
                            }

                            #endregion
                            AgregarCalificacion(calificacion);

                        }
                    }
                }

                



            } while (!FinishCalificacion);
        }



    }
}
