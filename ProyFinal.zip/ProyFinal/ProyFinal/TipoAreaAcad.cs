﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyFinal
{
    public enum TipoAreaAcad
    {
        CBA = 1,
        CS,
        CSH,
        ING,
        ECO
    }
}
